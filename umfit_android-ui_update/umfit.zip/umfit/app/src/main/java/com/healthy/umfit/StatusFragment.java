package com.healthy.umfit;

import android.content.Context;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.healthy.umfit.entity.Activity;
import com.healthy.umfit.entity.HeartRate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static com.healthy.umfit.TagName.KEY_ACTIVITIES;
import static com.healthy.umfit.TagName.KEY_HEART_RATES;
import static com.healthy.umfit.TagName.userUrl;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link StatusFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link StatusFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class StatusFragment extends Fragment {
    private static final String TAG = StatusFragment.class.getSimpleName();

    private String urlHeartRate = "", urlActivities = "";
    private ArrayList<HeartRate> heartRateList = new ArrayList<>();
    private ArrayList<Activity> activityList = new ArrayList<>();
    private TextView tvSteps, tvWorkoutDesc, tvDistance, tvBurnedFat, tvHeartRate, tvLastSyncHeartRate;
    private ProgressBar pbStatus;
    private ScrollView svStatus;

    private String interval = "daily";
    private String currentDate = "", currentTimezone = "";

    private OnFragmentInteractionListener mListener;

    public StatusFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_status, container, false);

        View rootView = inflater.inflate(R.layout.fragment_status, container, false);

        svStatus = rootView.findViewById(R.id.sv_status);
        pbStatus = rootView.findViewById(R.id.pb_status);
        tvSteps = rootView.findViewById(R.id.tv_steps);
        tvWorkoutDesc = rootView.findViewById(R.id.tv_workout_desc);
        tvDistance = rootView.findViewById(R.id.tv_distance);
        tvBurnedFat = rootView.findViewById(R.id.tv_burned_fat);
        tvHeartRate = rootView.findViewById(R.id.tv_heart_rate);
        tvLastSyncHeartRate = rootView.findViewById(R.id.tv_last_sync_heart_rate);

        Date c = Calendar.getInstance().getTime();

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        currentDate = df.format(c);

        currentTimezone = TimeZone.getDefault().getID();

        try {
            svStatus.setVisibility(View.GONE);
            pbStatus.setVisibility(View.VISIBLE);

            urlActivities = userUrl + KEY_ACTIVITIES + "?startDate=" + currentDate + "&endDate=" + currentDate + "&interval=" + interval;
            runActivities();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return rootView;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

    private void runActivities() throws IOException {

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .header("Authorization", "Bearer AQVBQDpyQktGXip6SltGeiouXAQABAAAAAAN3AWzf3cnGXMxO18qpc-XBaUp56-T4-eDddfdynuAmaOPcgUzqTytaPTca64XeyH6C8DQeiOMbuTpemOg07SQ0EpdAr1unZ5ofcNhV509Yg66DVHpgUKmeECtJ05zQ8o4oGQBTUaHY7QFt3cXGYAH8_vMwuCtSaSqBR4IZ93G-")
                .url(urlActivities)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "call: " + call);
                Log.d(TAG, "reponse: " + response);
                final String myResponse = response.body().string();

                try {
                    JSONObject joActivity = new JSONObject(myResponse);
                    if (joActivity.has("items")) {
                        String items = joActivity.getString("items");
                        JSONArray jaItems = new JSONArray(items);
                        for (int i = 0; i < jaItems.length(); i++) {
                            JSONObject joItems = jaItems.getJSONObject(i);
                            Activity activityObj = new Activity(joItems);

                            activityList.add(activityObj);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
//                        if (heartRateObj != null) {
                        if (activityList.size() > 0) {
                            if (interval.equalsIgnoreCase("daily")) {
                                tvSteps.setText(activityList.get(0).getSteps());
                                if (activityList.get(0).getActivityStageList().size() > 0) {
                                    tvWorkoutDesc.setText(getResources().getString(R.string.txt_workout_description)
                                            .replace("[minute]", activityList.get(0).getActivityStageList().get(activityList.get(0).getActivityStageList().size() - 1).getTimeDifference())
                                            .replace("[calories]", activityList.get(0).getActivityStageList().get(activityList.get(0).getActivityStageList().size() - 1).getCal()));
                                    tvWorkoutDesc.setVisibility(View.VISIBLE);
                                } else {
                                    tvWorkoutDesc.setVisibility(View.GONE);
                                }

                                String strDistance = getResources().getString(R.string.txt_distance_today_msg).replace("[distance]", activityList.get(0).getDistance());
                                int distanceTextCount = activityList.get(0).getDistance().length();
                                SpannableString ssDistance = new SpannableString(strDistance);
                                ssDistance.setSpan(new RelativeSizeSpan(1.5f), 9, 9 + distanceTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); // set size
                                ssDistance.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 9, 9 + distanceTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                                tvDistance.setText(ssDistance);

                                String strBurnedFat = getResources().getString(R.string.txt_burned_fat_msg).replace("[calories]", activityList.get(0).getCalories());
                                int burnedFatTextCount = activityList.get(0).getCalories().length();
                                SpannableString ssBurnedFat = new SpannableString(strBurnedFat);
                                ssBurnedFat.setSpan(new RelativeSizeSpan(1.5f), 7, 7 + burnedFatTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); // set size
                                ssBurnedFat.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 7, 7 + burnedFatTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                                tvBurnedFat.setText(ssBurnedFat);
                            }
                        }else{
                            if(interval.equalsIgnoreCase("daily")){
                                tvSteps.setText("0");
                                tvWorkoutDesc.setText(getResources().getString(R.string.txt_workout_description)
                                        .replace("[minute]", "0")
                                        .replace("[calories]", "0"));
                                tvWorkoutDesc.setVisibility(View.VISIBLE);

                                String strDistance = getResources().getString(R.string.txt_distance_today_msg).replace("[distance]", "0");
                                int distanceTextCount = 1;
                                SpannableString ssDistance = new SpannableString(strDistance);
                                ssDistance.setSpan(new RelativeSizeSpan(1.5f), 9, 9 + distanceTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); // set size
                                ssDistance.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 9, 9 + distanceTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                                tvDistance.setText(ssDistance);

                                String strBurnedFat = getResources().getString(R.string.txt_burned_fat_msg).replace("[calories]", "0");
                                int burnedFatTextCount = 1;
                                SpannableString ssBurnedFat = new SpannableString(strBurnedFat);
                                ssBurnedFat.setSpan(new RelativeSizeSpan(1.5f), 7, 7 + burnedFatTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); // set size
                                ssBurnedFat.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 7, 7 + burnedFatTextCount, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                                tvBurnedFat.setText(ssBurnedFat);
                            }
                        }


                        try {
                            Log.d(TAG, "timezone: " + currentTimezone);
                            urlHeartRate = userUrl + KEY_HEART_RATES + "?startDate=" + currentDate + "&endDate=" + currentDate + "&timezone=" + currentTimezone + "&type=ALL";

                            runHeartRate();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
//                        }

                    }
                });

            }
        });

    }

    private void runHeartRate() throws IOException {

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .header("Authorization", "Bearer AQVBQDpyQktGXip6SltGeiouXAQABAAAAAAN3AWzf3cnGXMxO18qpc-XBaUp56-T4-eDddfdynuAmaOPcgUzqTytaPTca64XeyH6C8DQeiOMbuTpemOg07SQ0EpdAr1unZ5ofcNhV509Yg66DVHpgUKmeECtJ05zQ8o4oGQBTUaHY7QFt3cXGYAH8_vMwuCtSaSqBR4IZ93G-")
                .url(urlHeartRate)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "call: " + call);
                Log.d(TAG, "reponse: " + response);
                final String myResponse = response.body().string();

                try {
                    JSONObject joHeartRate = new JSONObject(myResponse);
                    if (joHeartRate.has("items")) {
                        String items = joHeartRate.getString("items");
                        JSONArray jaItems = new JSONArray(items);
                        for (int i = 0; i < jaItems.length(); i++) {
                            JSONObject joItems = jaItems.getJSONObject(i);
                            HeartRate heartRateObj = new HeartRate(joItems);

                            heartRateList.add(heartRateObj);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (heartRateList.size() > 0) {
                            for (int i = 0; i < heartRateList.size(); i++) {
                                if (heartRateList.get(i).getHeartRateDataInInteger() > 0) {
                                    tvHeartRate.setText(getResources().getString(R.string.txt_heart_rate_value).replace("[heart_rate]", heartRateList.get(i).getHeartRateData()));
                                    tvLastSyncHeartRate.setText(heartRateList.get(i).getFormattedDateFromTimestamp());
                                    break;
                                }
                            }
                        }

                        svStatus.setVisibility(View.VISIBLE);
                        pbStatus.setVisibility(View.GONE);


                    }
                });

            }
        });

    }
}

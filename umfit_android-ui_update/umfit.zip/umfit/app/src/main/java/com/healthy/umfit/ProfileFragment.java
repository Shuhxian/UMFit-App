package com.healthy.umfit;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.healthy.umfit.entity.Profile;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static com.healthy.umfit.TagName.KEY_PROFILE;
import static com.healthy.umfit.TagName.userUrl;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link ProfileFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment {
    private static final String TAG = ProfileFragment.class.getSimpleName();

    private String url = userUrl + KEY_PROFILE;
    private Profile profileObj;
    private TextView tvUserId, tvName, tvGender, tvBirthday, tvHeight, tvWeight, tvActivityGoal;
    private RelativeLayout rlActivityGoal, rlBehaviorTagging, rlLogOut;
    private ProgressBar pbProfile;
    private ScrollView svProfile;

    private OnFragmentInteractionListener mListener;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_profile, container, false);

        View rootView = inflater.inflate(R.layout.fragment_profile, container, false);
        findViewById(rootView);
        setOnClick();

//        new getProfileDetailsTask().execute();

        return rootView;
    }

    private void findViewById(View rootView){
        tvUserId = rootView.findViewById(R.id.tv_user_id);
        tvName = rootView.findViewById(R.id.tv_name);
        tvGender = rootView.findViewById(R.id.tv_gender);
        tvBirthday = rootView.findViewById(R.id.tv_birthday);
        tvHeight = rootView.findViewById(R.id.tv_height);
        tvWeight = rootView.findViewById(R.id.tv_weight);
        tvActivityGoal = rootView.findViewById(R.id.tv_activity_goal);
        rlActivityGoal = rootView.findViewById(R.id.rl_activity_goal);
        rlBehaviorTagging = rootView.findViewById(R.id.rl_behavior_tagging);
        rlLogOut = rootView.findViewById(R.id.rl_log_out);
        pbProfile = rootView.findViewById(R.id.pb_profile);
        svProfile = rootView.findViewById(R.id.sv_profile);

        try {
            svProfile.setVisibility(View.GONE);
            pbProfile.setVisibility(View.VISIBLE);

            tvActivityGoal.setText(getResources().getString(R.string.txt_steps_count).replace("[step]", "8000"));
            run();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void setOnClick(){
        rlActivityGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), GoalActivity.class);
//                intent.putExtra(EXTRA_MESSAGE, message);
                startActivityForResult(intent,1);
            }
        });

        rlLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "logout", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    private class getProfileDetailsTask extends AsyncTask<Void, Void,Void>{
        OkHttpClient client = new OkHttpClient();

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pbProfile.setVisibility(View.VISIBLE);
            svProfile.setVisibility(View.GONE);

        }

        @Override
        protected Void doInBackground(Void... voids) {
//            try {
//                run();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }

            Request request = new Request.Builder()
                    .header("Authorization", "Bearer AQVBQDpyQktGXip6SltGeiouXAQABAAAAAAN3AWzf3cnGXMxO18qpc-XBaUp56-T4-eDddfdynuAmaOPcgUzqTytaPTca64XeyH6C8DQeiOMbuTpemOg07SQ0EpdAr1unZ5ofcNhV509Yg66DVHpgUKmeECtJ05zQ8o4oGQBTUaHY7QFt3cXGYAH8_vMwuCtSaSqBR4IZ93G-")
                    .url(url)
                    .build();

//            try {
//                Response response = client.newCall(request).execute();
//                final String mResponse = response.body().toString();
//                profileObj = new Profile(mResponse);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    call.cancel();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    Log.d(TAG, "call: " + call);
                    Log.d(TAG, "reponse: " + response);
                    final String myResponse = response.body().string();
                    profileObj = new Profile(myResponse);
                    Log.d(TAG, "profileobj: " + profileObj);

                }

            });

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            pbProfile.setVisibility(View.GONE);
            svProfile.setVisibility(View.VISIBLE);
            if(isAdded()){
                if(profileObj != null) {
                    tvName.setText(profileObj.getNickName());
                    if (profileObj.getGender().equalsIgnoreCase("0")) {
                        tvGender.setText("Female");
                    } else {
                        tvGender.setText("Male");
                    }
                    tvBirthday.setText(profileObj.getBirthday());
                    tvHeight.setText(profileObj.getHeight());
                    tvWeight.setText(profileObj.getWeight());
                }
            }
        }


    }

    private void run() throws IOException {

        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .header("Authorization", "Bearer AQVBQDpyQktGXip6SltGeiouXAQABAAAAAAN3AWzf3cnGXMxO18qpc-XBaUp56-T4-eDddfdynuAmaOPcgUzqTytaPTca64XeyH6C8DQeiOMbuTpemOg07SQ0EpdAr1unZ5ofcNhV509Yg66DVHpgUKmeECtJ05zQ8o4oGQBTUaHY7QFt3cXGYAH8_vMwuCtSaSqBR4IZ93G-")
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                call.cancel();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, "call: " + call);
                Log.d(TAG, "reponse: " + response);
                final String myResponse = response.body().string();
                profileObj = new Profile(myResponse);
                Log.d(TAG, "profileobj: " + profileObj);
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        svProfile.setVisibility(View.VISIBLE);
                        pbProfile.setVisibility(View.GONE);
                        tvUserId.setText(getResources().getString(R.string.txt_user_id).replace("[user_id]", profileObj.getUserId()));
                        tvName.setText(profileObj.getNickName());
                        if(profileObj.getGender().equalsIgnoreCase("0")){
                            tvGender.setText("Female");
                        }else{
                            tvGender.setText("Male");
                        }
                        tvBirthday.setText(profileObj.getBirthday());
                        tvHeight.setText(profileObj.getHeightInCm());
                        tvWeight.setText(profileObj.getWeightInKg());
                    }
                });

            }
        });

    }
}

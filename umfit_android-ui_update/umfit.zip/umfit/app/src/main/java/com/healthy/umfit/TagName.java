package com.healthy.umfit;

public class TagName {
    public static String userUrl = "https://api-open.huami.com/users/-/";

    public static String KEY_PROFILE = "profile";
    public static String KEY_ACTIVITIES = "activities";
    public static String KEY_SLEEP = "sleep";
    public static String KEY_HEART_RATES = "heartrates";
    public static String KEY_MOTION_IN_MINUTES = "motionInMinute";
    public static String KEY_BODY = "body";
    public static String KEY_DEVICES = "devices";
    public static String KEY_SPORTS = "sports";
    public static String KEY_SPORT_DETAIL = "sportDetail";
    public static String KEY_SOCIAL = "social";
    public static String KEY_NOTIFICATIONS = "notifications";
}

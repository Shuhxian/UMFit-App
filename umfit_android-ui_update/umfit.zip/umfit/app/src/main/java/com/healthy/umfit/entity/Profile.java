package com.healthy.umfit.entity;

import org.json.JSONObject;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Profile implements Serializable {
    private String userId;
    private String gender;
    private String birthday;
    private String height;
    private String weight;
    private String nickName;

    public Profile(String profileStr) {
        try {
            JSONObject joProfile = new JSONObject(profileStr);

            userId = joProfile.getString("userId");
            gender = joProfile.getString("gender");
            birthday = joProfile.getString("birthday");
            height = joProfile.getString("height");
            weight = joProfile.getString("weight");
            nickName = joProfile.getString("nickName");

        } catch (Exception e) {

        }
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthday() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM");
        Date sourceDate = null;
        try {
            sourceDate = dateFormat.parse(birthday);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        SimpleDateFormat targetFormat = new SimpleDateFormat("MMMM yyyy");
        birthday = targetFormat.format(sourceDate);
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getHeight() {
        return height;
    }

    public String getHeightInCm() {
        return height.replace(".0", "") + " cm";
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public String getWeightInKg() {
        return weight + "0kg";
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }
}
